﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ClassLibrary1;
using Microsoft.Win32;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            string idioma = ElegirIdioma();
            List<Registro> historial = new List<Registro>();
            string rutaArchivo = "historial.txt";

            if (File.Exists(rutaArchivo))
            {
                historial = Utilidades.CargarHistorial(rutaArchivo);
            }

            while (true)
            {
                Console.Clear();
                MostrarLogo();
                Console.WriteLine("=== MenteClara ===");
                Console.WriteLine("1. Registrar estado de ánimo y estrés");
                Console.WriteLine("2. Ver historial");
                Console.WriteLine("3. Editar historial");
                Console.WriteLine("4. Eliminar historial");
                Console.WriteLine("0. Salir");
                Console.Write("Elige una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Registro nuevo = Utilidades.RegistrarEntrada(idioma);
                        historial.Add(nuevo);
                        Utilidades.GuardarHistorial(rutaArchivo, historial);
                        break;
                    case "2":
                        Utilidades.VerHistorial(historial);
                        break;
                    case "3":
                        Utilidades.EditarHistorial(historial);
                        Utilidades.GuardarHistorial(rutaArchivo, historial);
                        break;
                    case "4":
                        Utilidades.EliminarHistorial(historial);
                        Utilidades.GuardarHistorial(rutaArchivo, historial);
                        break;
                    case "0":
                        Console.WriteLine("Gracias por usar MenteClara ❤");
                        return;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }

                Console.WriteLine("Presiona una tecla para continuar...");
                Console.ReadKey();
            }
        }

        static string ElegirIdioma()
        {
            Console.Clear();
            Console.WriteLine("¿En qué idioma deseas las frases motivadoras?");
            Console.WriteLine("E - Español");
            Console.WriteLine("I - Inglés");
            Console.Write("Tu opción: ");
            string idioma = Console.ReadLine()?.ToUpper();
            return (idioma == "I") ? "EN" : "ES";
        }

        static void MostrarLogo()
        {
            Console.WriteLine("     _____       _             _     _             ");
            Console.WriteLine("    |     | ___ | | ___  _ _ _| |_  |_|___ ___ ___ ");
            Console.WriteLine("    | | | || -_|| || . || | | |  _| | |  _| -_|_ -|");
            Console.WriteLine("    |_|_|_||___||_||___||_____|_|   |_|_| |___|___|");
            Console.WriteLine("              Bienvenido a MenteClara 😊");
            Console.WriteLine();
        }
    }
}

