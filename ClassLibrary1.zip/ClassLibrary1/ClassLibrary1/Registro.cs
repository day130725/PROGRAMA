﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ClassLibrary1
{
    public class Registro
    {
        public string Nombre;
        public int Edad;
        public string Universidad;
        public int Animo;
        public int Estres;
        public bool Ahorra;
        public double MontoAhorro;
    }

    public static class Utilidades
    {
        public static Registro RegistrarEntrada(string idioma)
        {
            Console.Clear();
            Registro r = new Registro();
            Console.Write("Nombre: ");
            r.Nombre = Console.ReadLine();
            Console.Write("Edad: ");
            r.Edad = int.Parse(Console.ReadLine());
            Console.Write("Universidad: ");
            r.Universidad = Console.ReadLine();

            Console.Write("Nivel de ánimo (1-10): ");
            r.Animo = int.Parse(Console.ReadLine());

            Console.Write("Nivel de estrés (1-5): ");
            r.Estres = int.Parse(Console.ReadLine());

            Console.Write("¿Estás ahorrando? (s/n): ");
            r.Ahorra = Console.ReadLine().ToLower() == "s";

            if (r.Ahorra)
            {
                Console.Write("¿Cuánto estás ahorrando? S/: ");
                r.MontoAhorro = double.Parse(Console.ReadLine());
            }
            else
            {
                Console.WriteLine("¿Por qué no estás ahorrando?");
                Console.WriteLine("1. Pagos universitarios");
                Console.WriteLine("2. Emergencias");
                Console.WriteLine("3. Otro");

                Console.ReadLine();

                Console.WriteLine("\nIdeas para comenzar a ahorrar:");
                Console.WriteLine("- Guarda el vuelto.");
                Console.WriteLine("- Lleva comida desde casa.");
                Console.WriteLine("- Usa transporte público.");
                Console.WriteLine("¿Te gustaría que te ayudemos a gestionar tu dinero? (s/n)");
                if (Console.ReadLine().ToLower() == "s")
                {
                    Console.WriteLine("Puedes empezar con un Excel o app como Fintonic o Wallet.");
                }
            }

            MostrarFraseMotivadora(r.Animo, idioma);
            return r;
        }

        public static void MostrarFraseMotivadora(int nivel, string idioma)
        {
            string[] frasesES = {
                "Está bien si hoy solo puedes respirar. Eso también es avanzar.",
                "Aunque no veas el camino, seguir de pie ya es valentía.",
                "No tener mucho no te hace débil; seguir soñando te hace fuerte.",
                "Un día difícil no define tu destino. Mañana puedes volver a empezar.",
                "No importa cuánto tengas. Importa cuánto crees en ti.",
                "Tú vales más que cualquier deuda, y mereces paz más que perfección.",
                "Cada caída te está enseñando cómo levantarte más firme.",
                "No vine al mundo solo para sobrevivir. Vine a construir algo mejor.",
                "No tengo miedo al futuro, porque ya vencí al pasado.",
                "Puedo perder dinero, tiempo o fuerza... pero nunca perderé mi determinación."
            };

            string[] frasesEN = {
                "It's okay if today you can only breathe. That too is progress.",
                "Even if you can't see the path, standing tall is courage.",
                "Having little doesn’t make you weak; dreaming makes you strong.",
                "A hard day doesn't define your fate. Tomorrow is a fresh start.",
                "It’s not how much you have, but how much you believe in yourself.",
                "You're worth more than any debt and deserve peace over perfection.",
                "Every fall teaches you to rise stronger.",
                "I wasn't born just to survive. I came to build something better.",
                "I'm not afraid of the future—I already conquered the past.",
                "I may lose money, time, or strength... but never my determination."
            };

            int index = Math.Max(0, Math.Min(nivel - 1, 9));
            Console.WriteLine("\n💬 " + (idioma == "EN" ? frasesEN[index] : frasesES[index]) + "\n");
        }

        public static void VerHistorial(List<Registro> lista)
        {
            Console.Clear();
            for (int i = 0; i < lista.Count; i++)
            {
                Registro r = lista[i];
                Console.WriteLine($"{i + 1}. {r.Nombre}, {r.Edad} años, {r.Universidad} | Ánimo: {r.Animo} | Estrés: {r.Estres} | Ahorra: {r.Ahorra} S/{r.MontoAhorro}");
            }
        }

        public static void EditarHistorial(List<Registro> lista)
        {
            VerHistorial(lista);
            Console.Write("Selecciona número a editar: ");
            int i = int.Parse(Console.ReadLine()) - 1;
            if (i >= 0 && i < lista.Count)
            {
                lista[i] = RegistrarEntrada("ES");
                Console.WriteLine("Editado exitosamente.");
            }
        }

        public static void EliminarHistorial(List<Registro> lista)
        {
            VerHistorial(lista);
            Console.Write("Selecciona número a eliminar: ");
            int i = int.Parse(Console.ReadLine()) - 1;
            if (i >= 0 && i < lista.Count)
            {
                lista.RemoveAt(i);
                Console.WriteLine("Eliminado.");
            }
        }

        public static void GuardarHistorial(string ruta, List<Registro> lista)
        {
            using (StreamWriter sw = new StreamWriter(ruta))
            {
                foreach (Registro r in lista)
                {
                    sw.WriteLine($"{r.Nombre}|{r.Edad}|{r.Universidad}|{r.Animo}|{r.Estres}|{r.Ahorra}|{r.MontoAhorro}");
                }
            }
        }

        public static List<Registro> CargarHistorial(string ruta)
        {
            List<Registro> lista = new List<Registro>();
            foreach (string linea in File.ReadAllLines(ruta))
            {
                string[] datos = linea.Split('|');
                lista.Add(new Registro
                {
                    Nombre = datos[0],
                    Edad = int.Parse(datos[1]),
                    Universidad = datos[2],
                    Animo = int.Parse(datos[3]),
                    Estres = int.Parse(datos[4]),
                    Ahorra = bool.Parse(datos[5]),
                    MontoAhorro = double.Parse(datos[6])
                });
            }
            return lista;
        }
    }
}

